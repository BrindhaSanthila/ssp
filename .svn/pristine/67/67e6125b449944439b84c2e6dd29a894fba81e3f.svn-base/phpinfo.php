<?php

echo phpinfo();
?>