<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>saravanachemdyes</title>
</head>
<link rel="stylesheet" href="assets/css/bootstrap.css" type="text/css">
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<link rel="stylesheet" href="assets/css/hover.css" type="text/css">
<script src="assets/js/jquery-3.2.1.min.js"></script>

<body>
<div class="login-bg">
<div class="row">
  <div class="col-md-6 col-xs-6 col-sm-6 col-lg-6">
<img class="logo flipInY" src="assets/img/welcome.png" width="350px" height="350px">

</div>

<div class="col-md-6 col-xs-6 col-sm-6 col-lg-6">
<div class="log-bg flipInY">
<center>
<form>
<h4 class="log-in">Login</h4>
<hr style="border-color:#eee;">
<input type="text" class="form-control txt" placeholder="Username" required>

<input type="password" class="form-control txt" placeholder="Password" required>

<hr style="border-color:#eee;">
<a class="btn1 hvr-grow" href="dashboard.php">Login</a>

</form>
</center>
</div>

</div>
</div>
</div>
</body>


<style>
body{
	background-image:url(assets/img/logbg.jpg); 
	width:100%;
	height:100vh; 
	background-epeat:no-repeat;
	background-size:cover !important;
	overflow:hidden;
	
}
</style>